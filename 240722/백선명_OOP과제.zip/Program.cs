﻿namespace _240722
{
    public class Character
    {
        int level;
        int hp;
        int dmg;
        float speed;

        public void Forward()
        {
        }

        public void Backward()
        {
        }

        public void TurnLeft()
        {
        }

        public void TurnRight()
        {
        }

        public void Attack()
        {
        }

        public void Defense()
        {
        }

    }

    internal class Program
    {
         
        static void Main(string[] args)
        {
            Character character = new Character();
             
        }
    }
}
